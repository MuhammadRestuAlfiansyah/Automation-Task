from select import select
import time
from xml.dom.minidom import Element
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
#options = webdriver.ChromeOptions()
#options.add_experimental_option('excludeSwitches', ['enable-logging'])

driver = webdriver.Chrome()

driver.get("https://rahulshettyacademy.com/angularpractice/")
driver.find_element(By.NAME, 'name').send_keys('Muhammad Restu Alfiansyah')
driver.find_element(By.NAME, 'email').send_keys('m.restualfiansyah@gmail.com')
driver.find_element(By.ID, 'exampleInputPassword1').send_keys('tes123')
driver.find_element(By.NAME, 'bday').send_keys('08/03/2000')
