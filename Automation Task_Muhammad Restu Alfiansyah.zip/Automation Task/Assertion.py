import unittest
from selenium import webdriver


class Test(unittest.TestCase):
    def testName(self):
        driver=webdriver.Chrome()
        driver.get("https://rahulshettyacademy.com/angularpractice/")
        titleOfWebPage=driver.title

        self.assertEqual("ProtoCommmerce",titleOfWebPage,"webpage title are not same")
        #self.assertNotEqual("Google", titleOfWebPage)
if __name__ == "__main__":
    unittest.main()